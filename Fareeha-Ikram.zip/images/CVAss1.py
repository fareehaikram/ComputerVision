import cv2

import  os  
import sys
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from sympy import *
from scipy import ndimage

def Loadimage():
    img1=cv2.imread("01.jpg")

    img2=cv2.imread("02.jpg")

    img3=cv2.imread("03.png")

    img4=cv2.imread("04.jpg")

    img5=cv2.imread("05.jpg")

    img6=cv2.imread("06.jpeg")

    img7=cv2.imread("07.jpg")

    img8=cv2.imread("08.jpg")

    img9=cv2.imread("01.jpg",0)# 0 for Gray scale
    img10=cv2.imread("02.jpg",0)
    img11=cv2.imread("03.png",0)
    img12=cv2.imread("04.jpg",0)
    img13=cv2.imread("05.jpg",0)
    img14=cv2.imread("06.jpeg",0)
    img15=cv2.imread("07.jpg",0)
    img16=cv2.imread("08.jpg",0)


    img=[img1,img9,img2,img10,img3,img11,img4,img12,img5,img13,img6,img14,img7,img15,img8,img16]#make a list of all images for display
    return img
#display iamge function
def displayImage(image,title):
    plt.imshow(cv2.cvtColor(image,cv2.COLOR_BGR2RGB))
    plt.title(title)
    plt.show()


#TASK 1 show the set of images in RGB and GrayScale
def plotInline(): 
    columns=2 
    rows =8
    fig=plt.figure(figsize=(15, 15))
    
   
    img_list=Loadimage()
    
   # plt.title(title)
    for i in range(0, columns*rows):
        fig.add_subplot(rows, columns, i+1)
    #print(i)
    
        plt.imshow(cv2.cvtColor(img_list[i],cv2.COLOR_BGR2RGB))
    

    
    plt.show()
    
#Task 2
#rgb Exclusion
def rgbExclusion(image,color):#input parameters an rgb image and color to show
    brg_image = image.copy()
    if color == "Red":
        brg_image[:,:,0]=0#empty blue channel
        brg_image[:,:,1] = 0 #empty green channel
        # and we are left out with red channel
        displayImage(brg_image,"Red Channel")
      
    elif color == "Green" :
        brg_image[:,:,2]=0 #empty red channel
        brg_image[:,:,0] = 0 #empty blue channel
        # and we are left out with green channel
        displayImage(brg_image,"Green Channel")
      
    else:
        brg_image[:,:,2]=0#empty red channel
        brg_image[:,:,1] = 0 #empty green channel
        # and we are left out with blue channel
        displayImage(brg_image,"blue Channel")
       
    return image

#Task 3 



def DisplayHist(img_g):# input gray sacle image
    coloumns=4#for display
    rows=3#as we are taking 3 images
    j=0
    fig=plt.figure(figsize=(15, 15))#defining the figure size
    for i in range(0,rows):
        
        img0=img_g[i]
        j=j+1
        plt.subplot(rows,coloumns,j)
        plt.title('Orignal')
        plt.imshow(cv2.cvtColor(img0,cv2.COLOR_BGR2RGB))
        j=j+1
        plt.subplot(rows,coloumns,j)
        plt.title('Histogram of Original')
        plt.hist(img0.ravel(),256,[0,256])
        j=j+1
        plt.subplot(rows,coloumns,j)
        plt.title('Histogram Equalized Image')
        dst = cv2.equalizeHist(img0)
        plt.imshow(cv2.cvtColor(dst,cv2.COLOR_BGR2RGB))
        j=j+1
        plt.subplot(rows,coloumns,j)
        plt.title('Histogram of Equalized Image ')
        plt.hist(dst.ravel(),256,[0,256])
    
    
    plt.show()
    

#Task 4
def myConvolve2d(image, kernel):
    """
    In this function convolution operation is implemented from scratch
    # This function which takes an image and a kernel 
    # and returns the convolution of them
    # Args:
    #   image: a numpy array of size [image_height, image_width].
    #   kernel: a numpy array of size [kernel_height, kernel_width].
    # Returns:
    #   a numpy array of size [image_height, image_width] (convolution output).
    
    """
     
    kernel = np.flip(kernel)# Flip the kernel in all axis
    output = np.zeros_like(image)   # convolution output
    #image_padded=image
    a=int(kernel.shape[0]/2)#gives the number of rows and columns to add
    image_padded=cv2.copyMakeBorder(image,a , a, a, a, cv2.BORDER_CONSTANT, 0)
    # Add zero padding to the input image
   # image_padded = np.zeros((image.shape[0] +2, image.shape[1] + 2))   
   # image_padded[1:-1, 1:-1] = image
    
    # Loop over every pixel of the image and implement convolution operation (element wise multiplication and summation). 
    # You can use two loops. The result is stored in the variable output.
    
    for x in range(image.shape[0]):     # Loop over every pixel of the image
        for y in range(image.shape[1]):
            # element-wise multiplication and summation 
            output[x,y]=(kernel*image_padded[x:x+kernel.shape[0],y:y+kernel.shape[1]]).sum()
        
    
    return output

#Task 4
#comapare results
def Compare_Inbuilt_myconv(img,kernelsize,sharp):#takes an gray scale image,kernelsize for defining the size for smoothing and sharp defines the sharpening factor in the filter 
    
    
    fig=plt.figure(figsize=(15, 15))
    plt.gray()

#in-built blur function
    image = cv2.blur(img, (kernelsize,kernelsize))
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

    plt.subplot(2, 2, 1)
    plt.title('IN-BUILT BLUR FUNCTION')
    plt.imshow(image)

# Convolve the smoothing kernel (laplacian) and the image
    kernel = np.ones((kernelsize,kernelsize),np.float32)/(kernelsize**2) #blur
#Call the function my_convolve2d
    image_smooth = myConvolve2d(img,kernel)

    plt.subplot(2, 2, 2)

    plt.title(' BLUR with My CONV FUNCTION')
    plt.imshow(image_smooth,cmap=plt.cm.gray)

#in-built convolution func for Sharpening 
    kernel = np.array([[0, -1, 0], [0, sharp, 0], [0, -1, 0]])
# Applying cv2.filter2D function on our  image
    sharpen_img_1=cv2.filter2D(img,-1,kernel)

    plt.subplot(2, 2, 3)
    plt.title(' IN-BUILT  FUNCTION of convolution for sharpening')
    plt.imshow(sharpen_img_1)

# Convolve the sharpen kernel (laplacian) and the image

#Call the function my_convolve2d
    image_sharpen = myConvolve2d(img,kernel)

    plt.subplot(2, 2, 4)
    plt.title(' Sharpen with My CONV FUNCTION')
    plt.imshow(image_sharpen,cmap=plt.cm.gray)

    plt.show()

#TASK 5



def applyboxfilter(img_g,kernelsize):
    img1=img_g[0]
    img2=img_g[1]

    fig=plt.figure(figsize=(20, 10))

#5.1--BOX filter with Convolution
    kernel = np.ones((kernelsize, kernelsize), np.float32) / (kernelsize**2)
    image_smooth = cv2.filter2D(img1, -1, kernel) 

    
    plt.subplot(2,5,1)
    plt.title(' Box filter ')
    plt.imshow(image_smooth,cmap=plt.cm.gray)


    #5.2--Gaussian filter on original image
    g = cv2.GaussianBlur(img1, ( kernelsize, kernelsize), 0)
    plt.subplot(2,5,2)
    plt.title(' Gauusian filter ')
    plt.imshow(g)
    #5.3
   
  
    from skimage.util import random_noise
 
    # Add salt-and-pepper noise to the image.
    noise_img = random_noise(img1, mode='s&p',amount=0.3)
    noise_img = random_noise(noise_img, mode='gaussian',var=0.3)
 
  # The above function returns a floating-point image on the range [0, 1], thus we changed it to 'uint8'and from [0,255]
    noise_img = np.array(255*noise_img, dtype = 'uint8')
    # Display the noise image
    
    plt.subplot(2,5,3)
    plt.title('noise_image')

# Task5.4

    blurr_gaussian = cv2.GaussianBlur(noise_img,(kernelsize,kernelsize),0)
    blurr_median= cv2.medianBlur(noise_img,kernelsize)
    plt.imshow(noise_img)
    plt.subplot(2,5,4)
    plt.title(' noise_image blurred with Gauussian')
    plt.imshow(blurr_gaussian )
    plt.subplot(2,5,5)
    plt.title(' noise_image blurred with median')
    plt.imshow(blurr_median )



    
    
    
#5.1--BOX filter with Convolution on image 2    
    image_smooth = cv2.filter2D(img2, -1, kernel) 
    plt.subplot(2,5,6)
    plt.title(' Box filter')
    plt.imshow(image_smooth,cmap=plt.cm.gray)


    #5.2--Gaussian filter on original image
    g = cv2.GaussianBlur(img2, ( kernelsize, kernelsize), 0)
    plt.subplot(2,5,7)
    plt.title(' Gaussian filter ')
    plt.imshow(g)
    
    #5.3
   
 

 
  # Add salt-and-pepper noise to the image.
    noise_img = random_noise(img2, mode='s&p',amount=0.3)
    noise_img = random_noise(noise_img, mode='gaussian')
 
  # The above function returns a floating-point image on the range [0, 1], thus we changed it to 'uint8'and from [0,255]
    noise_img = np.array(255*noise_img, dtype = 'uint8')
    # Display the noise image
    
    plt.subplot(2,5,8)
    plt.title('noise_image')

# Task5.4

    blurr_gaussian = cv2.GaussianBlur(noise_img,(kernelsize,kernelsize),0)#apply gaussian smoothing
    blurr_median= cv2.medianBlur(noise_img,kernelsize)#apply median smoothing
    plt.imshow(noise_img)
    plt.subplot(2,5,9)
    plt.title(' noise_image blurred with Gauussian')
    plt.imshow(blurr_gaussian )
    plt.subplot(2,5,10)
    plt.title(' noise_image blurred with median')
    plt.imshow(blurr_median )




    plt.show()

#Task 5.5

def meshplotGauusian(sigma,sigma2):#comapre gaussian of 2 sigmas
    
 

    x=np.linspace(-10,10, num=100) #define the spxe grid for x and y
    y=np.linspace(-10,10, num=100)

    x, y = np.meshgrid(x, y)
    # Compute Gaussian 
    alpha=0.5*(1/(sigma**2))

    z = np.exp(-alpha*x**2-alpha*y**2)

    ee=np.gradient(z) #take gradient of Gaussian
    ee=np.array(ee)# convert list to np.array
    grad_x=ee[0,:,:]# resize 
    grad_x.reshape(100,100)

    grad_y=ee[1,:,:]
    grad_y.reshape(100,100)
    
    laplacian = cv2.Laplacian(z,cv2.CV_64F)#take lapcian of gaussian
    
    
    

    #mesh plotting 
    fig=plt.figure(figsize=(20, 10))
    ax = plt.subplot(241, projection='3d')
    plt.title('Gaussian_sigma1')
    ax.plot_surface(x,y,z, cmap=cm.jet)
    ax1 = plt.subplot(242, projection='3d')
    plt.title('Gaussian first derivative in x')
    ax1.plot_surface(x,y,grad_x, cmap=cm.jet)
    ax2 = plt.subplot(243, projection='3d')
    plt.title('Gaussian ist derivative in y')
    ax2.plot_surface(x,y,grad_y, cmap=cm.jet)
    ax3 = plt.subplot(244, projection='3d')
    plt.title('laplaccian of Gaussian ')
    ax3.plot_surface(x,y,laplacian, cmap=cm.jet)
    
    #for sigma=2
    # Compute Gaussian 
    alpha=0.5*(1/(sigma2**2))

    z = np.exp(-alpha*x**2-alpha*y**2)

    ee=np.gradient(z) #take gradient of Gaussian
    ee=np.array(ee)# convert list to np.array
    grad_x=ee[0,:,:]# resize 
    grad_x.reshape(100,100)

    grad_y=ee[1,:,:]
    grad_y.reshape(100,100)
    
    laplacian = cv2.Laplacian(z,cv2.CV_64F)
    
    #mesh plotting 
    fig=plt.figure(figsize=(20, 10))
    
   
    ax = plt.subplot(245, projection='3d')
    plt.title('Gaussian_sigma2')
    ax.plot_surface(x,y,z, cmap=cm.jet)
    ax1 = plt.subplot(246, projection='3d')
    plt.title('Gaussian first derivative in x')
    ax1.plot_surface(x,y,grad_x, cmap=cm.jet)
    ax2 = plt.subplot(247, projection='3d')
    plt.title('Gaussian ist derivative in y')
    ax2.plot_surface(x,y,grad_y, cmap=cm.jet)
    ax3 = plt.subplot(248, projection='3d')
    plt.title('laplaccian of Gaussian ')
    ax3.plot_surface(x,y,laplacian, cmap=cm.jet)


    plt.show()
#Task6

#6.1


def ApplySobel(img_g,kernelsize):
    #for image 1
    img=img_g[0]
    #compute sobel in x-direction and y-direction
    sx = cv2.Sobel(img,cv2.CV_64F,1,0,ksize=kernelsize)#dx=1,dy=0
    sy = cv2.Sobel(img,cv2.CV_64F,0,1,ksize=kernelsize)#dy=1,dx=0
    grad_mag=np.hypot(sx,sy)#finds the gradient magnitude
    #display
    plt.gray()
    plt.figure(figsize=(20,20))
    plt.subplot(241)
    plt.imshow(img)
    plt.title('original', size=20)
    plt.subplot(242)

    plt.imshow(sx)
    plt.title('sobel_x', size=20)
    plt.subplot(243)

    plt.imshow(sy)
    plt.title('sobel_y', size=20)
    plt.subplot(244)

    plt.imshow(grad_mag)
    plt.title('sobel magnitude', size=20)
    
    #for image 2
    img=img_g[1]
    
    sx = cv2.Sobel(img,cv2.CV_64F,1,0,ksize=kernelsize)
    sy = cv2.Sobel(img,cv2.CV_64F,0,1,ksize=kernelsize)
    grad_mag=np.hypot(sx,sy) 
    plt.figure(figsize=(20,20))
    plt.subplot(245)
    plt.imshow(img)
    plt.title('original', size=20)
    plt.subplot(246)

    plt.imshow(sx)
    plt.title('sobel_x', size=20)
    plt.subplot(247)

    plt.imshow(sy)
    plt.title('sobel_y', size=20)
    plt.subplot(248)

    plt.imshow(grad_mag)
    plt.title('sobel magnitude', size=20)
    
    
    plt.show()

#Task6.2

def ApplyLOG(img_g,sigma1,sigma2):
    #for image1
    img1=img_g[0]
    fig = plt.figure()
    plt.gray()  # show the filtered result in grayscale
       
     
   
    plt.subplot(231)
    plt.title('Original')
    plt.imshow(img1)
    result = ndimage.gaussian_laplace(img1, sigma1)#aplly LOG
    plt.subplot(232) 
    plt.title('LOG with sigma1')
    plt.imshow(result)

    result = ndimage.gaussian_laplace(img1, sigma2)
    plt.subplot(233)
    plt.title('LOG with sigma2')
    plt.imshow(result)
    
    #for image2
    img2=img_g[1]
    plt.subplot(234)  
    plt.title('Original')
    plt.imshow(img2)
    result = ndimage.gaussian_laplace(img2, sigma1)#aplly LOG
    plt.subplot(235) 
    plt.title('LOG with sigma1')
    plt.imshow(result)

    result = ndimage.gaussian_laplace(img2, sigma2)
    plt.subplot(236)
    plt.title('LOG with sigma2')
    plt.imshow(result)
    
    
    plt.show()
    
#Task6.3
def applyCanny(img_g,t1,t2):
    #for image1
    img1=img_g[0]
    edges = cv2.Canny(img1, t1, t2)#t1=100---first threshold for the hysteresis procedure.#t2=200 ---second threshold for the hysteresis procedure.


   
    fig=plt.figure(figsize=(20, 10))
    fig.add_subplot(2, 2, 1)
    plt.imshow(img1,cmap=plt.cm.gray)
    plt.title("GrayScale")
    fig.add_subplot(2, 2, 2).imshow(edges,cmap=plt.cm.gray)
    plt.title("Canny edge detector")
    
    #for image1
    img2=img_g[1]
    edges = cv2.Canny(img2, t1, t2)#t1=100---first threshold for the hysteresis procedure.#t2=200 ---second threshold for the hysteresis procedure.


    
    fig.add_subplot(2, 2,3 )
    plt.imshow(img2,cmap=plt.cm.gray)
    plt.title("GrayScale")
    fig.add_subplot(2, 2, 4).imshow(edges,cmap=plt.cm.gray)
    plt.title("Canny edge detector")
    
    plt.show()


